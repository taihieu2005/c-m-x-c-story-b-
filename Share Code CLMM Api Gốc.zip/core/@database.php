<?php
define('SERVERNAME','localhost');
define('USERNAME','clmmotk_check');
define('PASSWORD','clmmotk_check');
define('DATABASE','clmmotk_check');
?>